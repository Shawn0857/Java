package ObjectClass.Exception;

public class CircleException extends Exception{
	//String new 119;
}
